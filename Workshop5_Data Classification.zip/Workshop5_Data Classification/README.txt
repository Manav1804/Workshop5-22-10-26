Files:
- transform.js: JavaScript transformation script.
- medicationbyvolume.json: generated analysis dataset (medication, volume, general location only).
- written_answers.txt: draft written answers for Tasks 1 and 2.
- customers.json: original input dataset used by the script.

To run:
1. Install Node.js.
2. Keep all files in the same folder.
3. Run: node transform.js

The script writes medicationbyvolume.json in the current folder.
