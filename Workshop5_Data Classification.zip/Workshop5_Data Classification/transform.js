const fs = require("fs");

const inputFile = "customers.json";
const outputFile = "medicationbyvolume.json";

const customers = JSON.parse(fs.readFileSync(inputFile, "utf8"));

const medicationByVolume = customers.map((customer) => ({
  medication: customer.medication,
  volume: customer.volume,
  location: customer.city
}));

fs.writeFileSync(
  outputFile,
  JSON.stringify(medicationByVolume, null, 2),
  "utf8"
);

console.log(`Created ${outputFile} with ${medicationByVolume.length} records.`);
